var globalConfig = {    
    link : {
        defaultColor : "lightgrey", // default color of link "string"
        choColor : "red", // color of cho link "string",
        labelColor : "white"
    },  
    node : {
        size : 40, // sizeof the node "integer"
        defaultColor : "lightgray", // color of the node "string"
        choColor : "red"// color of cho node "string"
    },
    arrow: {
        fill: "white",
        stroke: "grey"
    },
    externalData : {
        nodeDataArray : [], // data node value 
        linkDataArray :[] // data link value 
    }
}